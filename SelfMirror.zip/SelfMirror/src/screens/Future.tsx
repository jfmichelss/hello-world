import { View, Text } from 'react-native';

export default function Future() {
  return (
    <View>
      <Text>Futuro</Text>
    </View>
  );
}
import { View, Text } from 'react-native';

export default function Home() {
  return (
    <View>
      <Text>Início</Text>
    </View>
  );
}
import { View, Text } from 'react-native';

export default function Register() {
  return (
    <View>
      <Text>Registrar</Text>
    </View>
  );
}
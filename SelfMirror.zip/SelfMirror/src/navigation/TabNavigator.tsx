import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import Home from '../screens/Home';
import Register from '../screens/Register';
import Future from '../screens/Future';
import Profile from '../screens/Profile';

const Tab = createBottomTabNavigator();

export default function TabNavigator() {
  return (
    <Tab.Navigator screenOptions={{ headerShown: false }}>
      <Tab.Screen name="Início" component={Home} />
      <Tab.Screen name="Registrar" component={Register} />
      <Tab.Screen name="Futuro" component={Future} />
      <Tab.Screen name="Perfil" component={Profile} />
    </Tab.Navigator>
  );
}